install python
install mysql
install flask
install virtualenv
install mysql connector
install numpy 
