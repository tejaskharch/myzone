from flask import Flask , render_template,request, session,redirect,make_response,make_response, jsonify
import json 
import razorpay
import mysql.connector as mc
import smtplib
import numpy as np
app = Flask (__name__)
app.secret_key = 'your_secret_key_here'
conn = mc.connect(host='localhost',
                  password='project',
                  user='root',
                  database='shop')
cursor = conn.cursor()
app.config['RAZORPAY_API_KEY'] = 'rzp_test_8llfBu4FrsT7yi'
app.config['RAZORPAY_API_SECRET'] = 'eRMEv9Es71ngL57qmGpWmMoL'

razorpay_client = razorpay.Client(auth=(app.config['RAZORPAY_API_KEY'], app.config['RAZORPAY_API_SECRET']))



if conn.is_connected:
    print("done") 

@app.route('/')
def products():
    return render_template('login.html')

@app.route('/getvalue' , methods=['POST'])  
def values():
    firstname=request.form['firstname']
    lastname=request.form['lastname']
    email=request.form['email']
    gender=request.form['gender']
    password1=request.form['confirm_password']
    password2=request.form['new_password']
    pnm="Password not same !!"
    sm = "myzonshopping@gmail.com"
    sp = "unikloglcjizapsj"
    otp = ''.join(str(np.random.randint(0, 9)) for _ in range(6))
    rec=(email)
    print(rec)
    connection = smtplib.SMTP("smtp.gmail.com")
    
    connection.starttls()
    connection.login(user=sm, password=sp)
    mailcontent = f"Subject: OTP for verification\n\nDear Customer \n\nWelcome to MyZon Shopping , This mail is for the verification for confirming that it's you \n\n if you have not attemp for login then ignore this mail \n\n Your OTP for logging in to MyZon Shopping is : {otp}"
    
    if password1==password2:
        try:
            connection.sendmail(from_addr=sm, to_addrs=rec, msg=mailcontent)
            session['email'] = email
            session['otp'] = otp
            session['firstname'] = firstname
            session['lastname'] = lastname
            session['gender'] = gender
            session['password1'] = password1
            session['cart'] = {}
        except Exception as e:
            print("something went wrong")
        return render_template('optverification.html',email=email)
    else:
        return render_template('signup.html',pnm=pnm)
    
@app.route('/getlogin', methods=['POST'])
def verification():
    entered_otp = request.form['input-otp']
    expected_otp = session.get('otp')
    email = session.get('email')
    firstname=session.get('firstname')
    lastname=session.get('lastname')
    gender=session.get('gender')
    passwordfinal=session.get('password1')
    
    if entered_otp == expected_otp:
        try:
            cursor.execute("INSERT INTO user (firstname, lastname, email, gender, password) VALUES (%s, %s, %s, %s, %s)",
                           (firstname, lastname, email, gender, passwordfinal))
            conn.commit() 
        except Exception as e:
            print("Something went wrong:", str(e))
            conn.rollback()
        return render_template('login.html')
    else:
        return render_template('optverification.html', email=email, error="Invalid OTP !!")
@app.route('/getshop', methods=['POST'])
def loginprocess():
    entered_mailid = request.form['loginemail']
    entered_password = request.form['loginpassword']
    cursor.execute("SELECT email, password, firstname FROM user WHERE email = %s", (entered_mailid,))
    result = cursor.fetchone()
    if result is not None and entered_password == result[1]:
        user_firstname = result[2]
        session['entered_mailid'] = entered_mailid
        session['user_firstname'] = user_firstname
        cursor.execute("SELECT pname, pprice, quantity, imagepath FROM product")
        products = cursor.fetchall()

        return render_template('shop.html', firstname=user_firstname, products=products, entered_mailid=entered_mailid)
    else:
        return render_template('login.html', error="Invalid Email or Password")
@app.route('/logout')
def logout():
    session.pop('entered_mailid', None)
    session.pop('user_firstname', None)
    return redirect('/')

                                                                                                                                       
@app.route('/signup')
def signup():
    return render_template('signup.html')
@app.route('/shop')
def shop():
    cursor.execute("SELECT pname, pprice, quantity , imagepath FROM product")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    print(products)
    return render_template('shop.html',firstname=user_firstname,products=products,)


@app.route('/cookware')
def cookware():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='cookware'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('cookware.html',firstname=user_firstname,products=products)

@app.route('/furniture')
def furniture():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='furniture'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('furniture.html',firstname=user_firstname,products=products)

@app.route('/decoration')
def decoration():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='decoration'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('decoration.html',firstname=user_firstname,products=products)

@app.route('/phone')
def phone():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='phone'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('phone.html',firstname=user_firstname,products=products) 

@app.route('/laptop')
def laptop():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='laptop'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('laptoppp.html',firstname=user_firstname,products=products)

@app.route('/watches')
def watches():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='watches'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('watches.html',firstname=user_firstname,products=products)

@app.route('/mens')
def mens():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='mens'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('mens.html',firstname=user_firstname,products=products)

@app.route('/womens')
def womens():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='womens'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('womens.html',firstname=user_firstname,products=products)

@app.route('/accessories')
def accessories():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='accessories'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('accessories.html',firstname=user_firstname,products=products)

@app.route('/makeup')
def makeup():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='makeup'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('makeup.html',firstname=user_firstname,products=products)

@app.route('/skincare')
def skincare():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='skincare'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('skincare.html',firstname=user_firstname,products=products)

@app.route('/haicare') 
def haicare():
    cursor.execute("Select pname,pprice,quantity,imagepath from Product Where category='haircare'")
    products = cursor.fetchall()
    user_firstname=session.get('user_firstname')
    return render_template('haircare.html',firstname=user_firstname,products=products)

    
@app.route('/addproduct', methods=['POST'])
def addproduct():
    pname = request.form["Productname"]
    pprice = int(request.form["productprice"])
    quantity = int(request.form["quantity"])
    category = request.form["category"]
    imagepath = request.form["imagepath"]

    cursor.execute("INSERT INTO product (pname, pprice, quantity, imagepath, category) VALUES (%s, %s, %s, %s, %s)",
                   (pname, pprice, quantity, imagepath, category))
    conn.commit()
    
    return render_template('add-product.html', prdadded="Product Added Successfully.")

@app.route('/neviaddprd')
def neviaddprd():
    return render_template('add-product.html')    



@app.route('/search', methods=['POST'])
def search():
    search = request.form['serach-bar']
    cursor.execute("SELECT pname, pprice, quantity, imagepath FROM product WHERE pname LIKE %s or category LIKE %s", ('%' + search + '%','%' + search + '%'))
    products = cursor.fetchall()
    
    if not products:
        return render_template('shop.html', error="No Such Results")
    
    return render_template('shop.html', products=products)

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    pname = request.form['pname']
    pprice = int(request.form['pprice'])
    entered_mailid = session.get('entered_mailid')
    if entered_mailid:
        cursor.execute("INSERT INTO cart1 (emailid, pname, pprice, quantity) VALUES (%s, %s, %s, 1) ON DUPLICATE KEY UPDATE quantity = quantity + 1",
                       (entered_mailid, pname, pprice))
        conn.commit()
    return redirect('shop')

@app.route('/cart')
def cart():
    entered_mailid = session.get('entered_mailid')
    
    if entered_mailid:
        cursor.execute("SELECT pname, pprice, quantity FROM cart1 WHERE emailid = %s", (entered_mailid,))
        cart_items = cursor.fetchall()
        total_price = sum(int(item[1]) * item[2] for item in cart_items)

        return render_template('cart.html', cart_items=cart_items, total_price=total_price)
    
    return render_template('cart.html', cart_items={}, total_price=0)


@app.route('/buy_now', methods=['POST'])
def buy_now():
    pname = request.form['pname']
    pprice = int(request.form['pprice'])
    entered_mailid = session.get('entered_mailid')

    if entered_mailid:
        cursor.execute("INSERT INTO cart1 (emailid, pname, pprice, quantity) VALUES (%s, %s, %s, 1) ON DUPLICATE KEY UPDATE quantity = quantity + 1",
                       (entered_mailid, pname, pprice))
        conn.commit()

    return redirect('/cart')



@app.route('/removeitem', methods=['POST'])
def removeitem():
    pname = request.form['pname']
    entered_mailid = session.get('entered_mailid')

    if entered_mailid:
        # Check the current quantity in the cart for the specified product
        cursor.execute("SELECT quantity FROM cart1 WHERE emailid = %s AND pname = %s", (entered_mailid, pname))
        current_quantity = cursor.fetchone()

        if current_quantity:
            current_quantity = current_quantity[0]
            if current_quantity > 1:
                # If quantity is greater than 1, decrement the quantity by 1
                cursor.execute("UPDATE cart1 SET quantity = quantity - 1 WHERE emailid = %s AND pname = %s", (entered_mailid, pname))
                conn.commit()
            else:
                # If quantity is 1, remove the item from the cart
                cursor.execute("DELETE FROM cart1 WHERE emailid = %s AND pname = %s", (entered_mailid, pname))
                conn.commit()

    return redirect('/cart')



# ... (other Flask app setup code)

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    entered_mailid = session.get('entered_mailid')

    if entered_mailid:
        # Fetch user-specific cart items and user's name from the database
        cursor.execute("SELECT pname, pprice, quantity FROM cart1 WHERE emailid = %s", (entered_mailid,))
        cart_items = cursor.fetchall()

        # Fetch user's name (Assuming the user's name is stored in a 'users' table)
        
        user_name = session.get('user_firstname')

        total_price = sum(int(item[1]) * item[2] for item in cart_items)

        if request.method == 'POST':
            user_name = session.get('user_firstname')
            return render_template('checkout.html', user_name=user_name, cart_items=cart_items, total_price=total_price)

    return "Invalid email ID"  # You can handle the case where the email ID is not provided




@app.route('/cancel_checkout', methods=['POST'])
def cancel_checkout():
    # Add code to handle canceling the checkout and return to the cart or another page
    return redirect('/cart')



@app.route('/proceed_checkout', methods=['POST'])
def proceed_checkout():
    entered_mailid = session.get('entered_mailid')
    user_firstname = session.get('user_firstname')

    if entered_mailid:
        # Fetch user-specific cart items from the database
        cursor.execute("SELECT pname, pprice, quantity FROM cart1 WHERE emailid = %s", (entered_mailid,))
        cart_items = cursor.fetchall()
        total_price = sum(int(item[1]) * item[2] for item in cart_items)

        if total_price > 0:
            # Create a Razorpay order
            order_amount = total_price * 100  # Convert amount to paise
            order_currency = 'INR'
            order_receipt = 'order_receipt_' + str(np.random.randint(1000, 9999))

            razorpay_order = razorpay_client.order.create({
                'amount': order_amount,
                'currency': order_currency,
                'receipt': order_receipt,
                'payment_capture': 1  # Auto-capture the payment
            })

            return render_template('rezorpay_checkout.html', user_name=user_firstname, cart_items=cart_items, total_price=total_price, order_id=razorpay_order['id'], razorpay_key=app.config['RAZORPAY_API_KEY'])
        else:
            return redirect('/cart')  # Handle the case where the cart is empty

    return "Invalid email ID"

@app.route('/payment_response', methods=['POST'])
def payment_response():
    # Obtain the response parameters from Razorpay
    params_dict = request.form.to_dict()
    razorpay_signature = params_dict['razorpay_signature']

    try:
        # Verify the payment signature
        razorpay_client.utility.verify_payment_signature(params_dict, razorpay_signature)
        return ('/paymentdone')  # Create a success template
    except razorpay.errors.SignatureVerificationError as e:
        # Handle signature verification failure
        return render_template('payment_failed.html', error=str(e))  # Create a failure template


@app.route('/paymentdone', methods=['POST'])
def paymentdone():
    entered_mailid = session.get('entered_mailid')

    if entered_mailid:
        # Fetch user-specific cart items from the database
        cursor.execute("SELECT pname, pprice, quantity FROM cart1 WHERE emailid = %s", (entered_mailid,))
        cart_items = cursor.fetchall()
        user_name = session.get('user_firstname')

        total_price = sum(int(item[1]) * item[2] for item in cart_items)

        if total_price > 0:
            order_id = ''.join(str(np.random.randint(0, 9)) for _ in range(5))
            
            for item in cart_items:
                pname = item[0]
                pprice = item[1]
                quantity = item[2]
                cursor.execute("SELECT quantity FROM product WHERE pname = %s", (pname,))
                product_quantity = cursor.fetchone()
                
                if product_quantity:
                    product_quantity = product_quantity[0]
                    
                    if product_quantity > 1:
                        cursor.execute("UPDATE product SET quantity = quantity - %s WHERE pname = %s", (quantity, pname))
                    else:
                        cursor.execute("DELETE FROM product WHERE pname = %s", (pname,))
                
                cursor.execute("INSERT INTO orders (emailid, order_id, pname, pprice, quantity, total_price) VALUES (%s, %s, %s, %s, %s, %s)",
                               (entered_mailid, order_id, pname, pprice, quantity, pprice * quantity))
                cursor.execute("DELETE FROM cart1 WHERE emailid = %s", (entered_mailid,))
            
            
            conn.commit()

            return render_template('invoice.html', user_name=user_name, cart_items=cart_items, total_price=total_price, order_id=order_id)
        else:
            return redirect('/cart')  # Handle the case where the cart is empty

    return "Invalid email ID"
   
    




@app.route('/admin')
def admin_login():
    return render_template('adminlogin.html')

@app.route('/admin_dashboard', methods=['POST'])
def admin_dashboard():
    admin_username = "admin"
    admin_password = "admin123"
    entered_username = request.form['username']
    entered_password = request.form['password']

    if entered_username == admin_username and entered_password == admin_password:
        cursor.execute("SELECT order_id, emailid, pname, pprice, quantity, total_price,order_date FROM orders")
        orders = cursor.fetchall()
        return render_template('dashboard.html', orders=orders)
    else:
        return render_template('adminlogin.html', error="Invalid username or password")

@app.route('/search_orders', methods=['POST'])
def search_orders():
    search_order_id = request.form['search-bar']  # Assuming 'search-bar' is a string

    # Use '%' around the search string for the LIKE clause and pass it as a tuple
    cursor.execute("SELECT order_id, emailid, pname, pprice, quantity, total_price,order_date FROM orders WHERE order_id LIKE %s", ('%' + search_order_id + '%',))
    orders = cursor.fetchall()

    if not orders:
        return render_template('dashboard.html', error="No Such Orders")
    
    return render_template('dashboard.html', orders=orders)

@app.route('/dashboard')
def dashboard():
    cursor.execute("SELECT order_id, emailid, pname, pprice, quantity, total_price,order_date FROM orders")
    orders = cursor.fetchall()
    return render_template('dashboard.html', orders=orders)









if __name__=="__main__":
    app.run(debug=True,port=8000)